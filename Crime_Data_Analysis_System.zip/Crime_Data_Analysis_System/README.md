# Crime Data Analysis System (Python Mini Project)

A beginner-friendly desktop mini project made with Python Tkinter, SQLite, CSV, and Matplotlib.

## Features
- Add, view, update, delete, and search crime records
- SQLite database is created automatically as `crime_data.db`
- Summary of total records, cities, and crime types
- Bar charts for crime type and city
- Export records to CSV
- Inserts sample/demo records on the first run

## Requirements
- Python 3.10 or newer recommended
- VS Code with the Python extension
- Matplotlib for charts (optional for the rest of the app)

## Run in VS Code
1. Extract the ZIP file.
2. Open the `crime_data_analysis_system` folder in VS Code.
3. Open Terminal > New Terminal.
4. Optional: install Matplotlib:
   `python -m pip install matplotlib`
5. Run:
   `python app.py`

On some Windows systems, use `py app.py` if `python app.py` does not work.

## Notes
- Tkinter and SQLite are included with most standard Python installations.
- The app creates `crime_data.db` in the same folder on first run.
- Included records are fictional demo data for educational use. They are not official crime statistics.
- Do not enter sensitive personal information into this demo application.
