import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
import csv

# Matplotlib is used only for charts. The main application works without it.
try:
    import matplotlib.pyplot as plt
    from collections import Counter
    CHARTS_AVAILABLE = True
except ImportError:
    CHARTS_AVAILABLE = False

DB_NAME = "crime_data.db"

SAMPLE_RECORDS = [
    ("2024-01-12", "Theft", "Yamuna Nagar", "Market Road", "Reported"),
    ("2024-02-08", "Cybercrime", "Chandigarh", "Sector 17", "Under Investigation"),
    ("2024-03-21", "Burglary", "Ambala", "Model Town", "Reported"),
    ("2024-04-05", "Assault", "Yamuna Nagar", "Bus Stand Area", "Under Investigation"),
    ("2024-05-17", "Theft", "Karnal", "Civil Lines", "Solved"),
    ("2024-06-02", "Fraud", "Chandigarh", "Industrial Area", "Reported"),
    ("2024-07-11", "Cybercrime", "Ambala", "City Centre", "Solved"),
    ("2024-08-29", "Vehicle Theft", "Yamuna Nagar", "Railway Road", "Reported"),
    ("2025-01-14", "Theft", "Karnal", "Main Market", "Under Investigation"),
    ("2025-02-19", "Fraud", "Ambala", "Model Town", "Reported"),
    ("2025-03-23", "Assault", "Chandigarh", "Sector 22", "Solved"),
    ("2025-04-09", "Burglary", "Yamuna Nagar", "Jagadhri Road", "Reported"),
]

class CrimeAnalysisApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Crime Data Analysis System")
        self.root.geometry("1120x700")
        self.root.minsize(950, 600)
        self.selected_id = None

        self.setup_database()
        self.build_ui()
        self.load_records()
        self.update_summary()

    def setup_database(self):
        with sqlite3.connect(DB_NAME) as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS crimes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    crime_date TEXT NOT NULL,
                    crime_type TEXT NOT NULL,
                    city TEXT NOT NULL,
                    location TEXT NOT NULL,
                    status TEXT NOT NULL
                )
            """)
            count = con.execute("SELECT COUNT(*) FROM crimes").fetchone()[0]
            if count == 0:
                con.executemany("""
                    INSERT INTO crimes (crime_date, crime_type, city, location, status)
                    VALUES (?, ?, ?, ?, ?)
                """, SAMPLE_RECORDS)

    def build_ui(self):
        title = tk.Label(
            self.root, text="CRIME DATA ANALYSIS SYSTEM",
            font=("Arial", 20, "bold"), pady=12
        )
        title.pack(fill="x")

        summary_frame = ttk.Frame(self.root, padding=(10, 0, 10, 10))
        summary_frame.pack(fill="x")
        self.total_label = ttk.Label(summary_frame, text="Total records: 0", font=("Arial", 11, "bold"))
        self.total_label.pack(side="left", padx=8)
        self.city_label = ttk.Label(summary_frame, text="Cities: 0", font=("Arial", 11, "bold"))
        self.city_label.pack(side="left", padx=20)
        self.type_label = ttk.Label(summary_frame, text="Crime types: 0", font=("Arial", 11, "bold"))
        self.type_label.pack(side="left", padx=20)

        form = ttk.LabelFrame(self.root, text="Crime Record Details", padding=10)
        form.pack(fill="x", padx=10, pady=5)

        ttk.Label(form, text="Date (YYYY-MM-DD)").grid(row=0, column=0, sticky="w", padx=5, pady=4)
        self.date_var = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        ttk.Entry(form, textvariable=self.date_var, width=18).grid(row=1, column=0, padx=5, pady=2)

        ttk.Label(form, text="Crime Type").grid(row=0, column=1, sticky="w", padx=5, pady=4)
        self.type_var = tk.StringVar()
        self.type_combo = ttk.Combobox(
            form, textvariable=self.type_var, width=18,
            values=["Theft", "Burglary", "Assault", "Fraud", "Cybercrime", "Vehicle Theft", "Robbery", "Other"]
        )
        self.type_combo.grid(row=1, column=1, padx=5, pady=2)
        self.type_combo.set("Theft")

        ttk.Label(form, text="City").grid(row=0, column=2, sticky="w", padx=5, pady=4)
        self.city_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.city_var, width=18).grid(row=1, column=2, padx=5, pady=2)

        ttk.Label(form, text="Location / Area").grid(row=0, column=3, sticky="w", padx=5, pady=4)
        self.location_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.location_var, width=22).grid(row=1, column=3, padx=5, pady=2)

        ttk.Label(form, text="Status").grid(row=0, column=4, sticky="w", padx=5, pady=4)
        self.status_var = tk.StringVar(value="Reported")
        ttk.Combobox(
            form, textvariable=self.status_var, width=18, state="readonly",
            values=["Reported", "Under Investigation", "Solved", "Closed"]
        ).grid(row=1, column=4, padx=5, pady=2)

        buttons = ttk.Frame(self.root, padding=(10, 5))
        buttons.pack(fill="x")
        ttk.Button(buttons, text="Add Record", command=self.add_record).pack(side="left", padx=4)
        ttk.Button(buttons, text="Update Selected", command=self.update_record).pack(side="left", padx=4)
        ttk.Button(buttons, text="Delete Selected", command=self.delete_record).pack(side="left", padx=4)
        ttk.Button(buttons, text="Clear Form", command=self.clear_form).pack(side="left", padx=4)
        ttk.Button(buttons, text="Export CSV", command=self.export_csv).pack(side="left", padx=4)
        ttk.Button(buttons, text="Crime Type Chart", command=self.show_type_chart).pack(side="right", padx=4)
        ttk.Button(buttons, text="City Chart", command=self.show_city_chart).pack(side="right", padx=4)

        search_frame = ttk.Frame(self.root, padding=(10, 5))
        search_frame.pack(fill="x")
        ttk.Label(search_frame, text="Search (crime type, city, area, status):").pack(side="left", padx=4)
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=35)
        search_entry.pack(side="left", padx=4)
        search_entry.bind("<KeyRelease>", lambda event: self.load_records())
        ttk.Button(search_frame, text="Show All", command=self.show_all).pack(side="left", padx=4)

        table_frame = ttk.Frame(self.root, padding=(10, 0, 10, 10))
        table_frame.pack(fill="both", expand=True)
        columns = ("id", "date", "crime_type", "city", "location", "status")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=15)
        headings = {
            "id": "ID", "date": "Date", "crime_type": "Crime Type",
            "city": "City", "location": "Location / Area", "status": "Status"
        }
        widths = {"id": 55, "date": 120, "crime_type": 160, "city": 150, "location": 240, "status": 190}
        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=widths[col], anchor="center")
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        footer = ttk.Label(
            self.root,
            text="Note: This mini project uses sample/demo records, not official crime statistics.",
            foreground="#555"
        )
        footer.pack(pady=(0, 8))

    def get_connection(self):
        return sqlite3.connect(DB_NAME)

    def validate_form(self):
        date = self.date_var.get().strip()
        crime_type = self.type_var.get().strip()
        city = self.city_var.get().strip()
        location = self.location_var.get().strip()
        status = self.status_var.get().strip()

        try:
            datetime.strptime(date, "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Invalid date", "Please enter the date in YYYY-MM-DD format, for example 2025-04-09.")
            return None

        if not all([crime_type, city, location, status]):
            messagebox.showwarning("Missing information", "Please fill in all fields.")
            return None
        return date, crime_type, city, location, status

    def add_record(self):
        values = self.validate_form()
        if not values:
            return
        with self.get_connection() as con:
            con.execute("""
                INSERT INTO crimes (crime_date, crime_type, city, location, status)
                VALUES (?, ?, ?, ?, ?)
            """, values)
        self.clear_form()
        self.load_records()
        self.update_summary()
        messagebox.showinfo("Success", "Crime record added successfully.")

    def update_record(self):
        if self.selected_id is None:
            messagebox.showwarning("Select a record", "Please select a row from the table first.")
            return
        values = self.validate_form()
        if not values:
            return
        with self.get_connection() as con:
            con.execute("""
                UPDATE crimes
                SET crime_date=?, crime_type=?, city=?, location=?, status=?
                WHERE id=?
            """, (*values, self.selected_id))
        self.clear_form()
        self.load_records()
        self.update_summary()
        messagebox.showinfo("Success", "Crime record updated successfully.")

    def delete_record(self):
        if self.selected_id is None:
            messagebox.showwarning("Select a record", "Please select a row from the table first.")
            return
        if not messagebox.askyesno("Confirm delete", "Delete the selected crime record?"):
            return
        with self.get_connection() as con:
            con.execute("DELETE FROM crimes WHERE id=?", (self.selected_id,))
        self.clear_form()
        self.load_records()
        self.update_summary()
        messagebox.showinfo("Deleted", "Crime record deleted.")

    def clear_form(self):
        self.selected_id = None
        self.date_var.set(datetime.now().strftime("%Y-%m-%d"))
        self.type_var.set("Theft")
        self.city_var.set("")
        self.location_var.set("")
        self.status_var.set("Reported")
        for item in self.tree.selection():
            self.tree.selection_remove(item)

    def on_select(self, _event=None):
        selection = self.tree.selection()
        if not selection:
            return
        values = self.tree.item(selection[0], "values")
        self.selected_id = int(values[0])
        self.date_var.set(values[1])
        self.type_var.set(values[2])
        self.city_var.set(values[3])
        self.location_var.set(values[4])
        self.status_var.set(values[5])

    def load_records(self):
        search = self.search_var.get().strip() if hasattr(self, "search_var") else ""
        for item in self.tree.get_children():
            self.tree.delete(item)
        with self.get_connection() as con:
            if search:
                pattern = f"%{search}%"
                rows = con.execute("""
                    SELECT id, crime_date, crime_type, city, location, status
                    FROM crimes
                    WHERE crime_type LIKE ? OR city LIKE ? OR location LIKE ? OR status LIKE ?
                    ORDER BY crime_date DESC, id DESC
                """, (pattern, pattern, pattern, pattern)).fetchall()
            else:
                rows = con.execute("""
                    SELECT id, crime_date, crime_type, city, location, status
                    FROM crimes ORDER BY crime_date DESC, id DESC
                """).fetchall()
        for row in rows:
            self.tree.insert("", "end", values=row)

    def show_all(self):
        self.search_var.set("")
        self.load_records()

    def update_summary(self):
        with self.get_connection() as con:
            total = con.execute("SELECT COUNT(*) FROM crimes").fetchone()[0]
            cities = con.execute("SELECT COUNT(DISTINCT city) FROM crimes").fetchone()[0]
            types = con.execute("SELECT COUNT(DISTINCT crime_type) FROM crimes").fetchone()[0]
        self.total_label.config(text=f"Total records: {total}")
        self.city_label.config(text=f"Cities: {cities}")
        self.type_label.config(text=f"Crime types: {types}")

    def export_csv(self):
        path = filedialog.asksaveasfilename(
            title="Save crime records as CSV",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")]
        )
        if not path:
            return
        with self.get_connection() as con:
            rows = con.execute("""
                SELECT id, crime_date, crime_type, city, location, status
                FROM crimes ORDER BY crime_date DESC
            """).fetchall()
        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["ID", "Date", "Crime Type", "City", "Location", "Status"])
                writer.writerows(rows)
            messagebox.showinfo("Export complete", f"Records exported to:\n{path}")
        except OSError as exc:
            messagebox.showerror("Export failed", f"Could not save the file:\n{exc}")

    def chart_data(self, column):
        with self.get_connection() as con:
            rows = con.execute(f"SELECT {column}, COUNT(*) FROM crimes GROUP BY {column} ORDER BY COUNT(*) DESC").fetchall()
        return rows

    def show_type_chart(self):
        self.show_chart("crime_type", "Crime Records by Type", "Crime Type")

    def show_city_chart(self):
        self.show_chart("city", "Crime Records by City", "City")

    def show_chart(self, column, title, xlabel):
        if not CHARTS_AVAILABLE:
            messagebox.showerror(
                "Matplotlib not installed",
                "Charts need Matplotlib. In the VS Code terminal run: python -m pip install matplotlib"
            )
            return
        rows = self.chart_data(column)
        if not rows:
            messagebox.showinfo("No data", "There are no records to display.")
            return
        labels = [str(row[0]) for row in rows]
        counts = [row[1] for row in rows]
        plt.figure(figsize=(9, 5))
        plt.bar(labels, counts)
        plt.title(title)
        plt.xlabel(xlabel)
        plt.ylabel("Number of records")
        plt.xticks(rotation=30, ha="right")
        plt.tight_layout()
        plt.show()

if __name__ == "__main__":
    root = tk.Tk()
    app = CrimeAnalysisApp(root)
    root.mainloop()
